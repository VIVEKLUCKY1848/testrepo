/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            //jquerymin:           'Darsh_Banner/js/jquery-1.11.3.min',         
            jqueryflexslider:      'Darsh_Banner/js/jquery.flexslider',               
            jquerybanner:           'Darsh_Banner/js/banner'            
        }
    }
};
