jQuery(document).ready(function(){
jQuery(window).load(function() {
    jQuery('.flexslider-8').flexslider({
        animation: "fade",        
        slideshowSpeed: 6000,
        minItems: 2,
        maxItems: 4,
        controlNav: true,        
    });
});
});
