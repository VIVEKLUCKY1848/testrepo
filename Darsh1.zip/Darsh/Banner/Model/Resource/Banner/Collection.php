<?php
namespace Darsh\Banner\Model\Resource\Banner;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Darsh\Banner\Model\Banner', 'Darsh\Banner\Model\Resource\Banner');
        $this->_map['fields']['page_id'] = 'main_table.page_id';
    }

}
?>
