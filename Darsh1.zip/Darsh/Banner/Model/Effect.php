<?php

namespace Darsh\Banner\Model;

class Effect
{
    /**#@+
     * Status values
     */
    //const BLINDX = 'BLINDX';

    //const BLINDY = 'BLINDY';

    /**
     * Retrieve option array
     *
     * @return string[]
     */
    public static function getOptionArray()
    {
        return ['blindX' => __('Blind X'), 'blindY' => __('blind Y'),'blindZ' => __('Blind Z'), 'cover' => __('Cover'),
        'curtainX' => __('Curtain X'), 'curtainY' => __('Curtain Y'),'fade' => __('Fade'), 'fadeZoom' => __('Fade Zoom'),
        'growX' => __('Grow X'), 'growY' => __('Grow Y'),'scrollUp' => __('Scroll Up'), 'scrollDown' => __('Scroll Down'),
        'scrollLeft' => __('Scroll Left'), 'scrollRight' => __('Scroll Right'),'scrollHorz' => __('Scroll Horizontal'), 'scrollVert' => __('Scroll Vertical'),
        'shuffle' => __('Shuffle'), 'toss' => __('Toss'),'turnUp' => __('Turn Up'), 'turnDown' => __('Turn Down'),
        'turnLeft' => __('Turn Left'), 'turnRight' => __('Turn Right'),'uncover' => __('Uncover'), 'wipe' => __('Wipe'),
        'zoom' => __('Zoom')];
    }

    /**
     * Retrieve option array with empty value
     *
     * @return string[]
     */
    public function getAllOptions()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }

    /**
     * Retrieve option text by option value
     *
     * @param string $optionId
     * @return string
     */
    public function getOptionText($optionId)
    {
        $options = self::getOptionArray();

        return isset($options[$optionId]) ? $options[$optionId] : null;
    }
}
