<?php

namespace Darsh\Banner\Block;

use Magento\Store\Model\Store;

class Banner extends \Magento\Framework\View\Element\Template {

    /**
     * @var \Darsh\Banner\Model\bannerFactory
     */
    protected $_bannerFactory;

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

    public function __construct(\Magento\Backend\Block\Widget\Context $context, \Darsh\Banner\Model\BannerFactory $bannerFactory,  array $data = []) {
        $this->_bannerFactory = $bannerFactory;
       
        parent::__construct($context, $data);
       


    }

    public function getCollection() {
        $collection = $this->_bannerFactory->create()->getCollection()->addFieldToFilter('is_active',1);
        return $collection;
    }

    public function getBannerImage($imageName) {
        //$unsecureBaseURL = $this->_config->getValue(Store::XML_PATH_UNSECURE_BASE_URL, 'default');
        $unsecureBaseURL = $this->getBaseUrl();
        $mediaDirectory = $unsecureBaseURL . 'pub/media/';
        return $mediaDirectory . 'bannerslider/images' . $imageName;
    }

}
