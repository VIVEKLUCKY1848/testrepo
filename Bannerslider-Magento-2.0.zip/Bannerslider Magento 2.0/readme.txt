1. Copy the source code to your installation folder (I copy the source code to C:\xampp\htdocs\magento22 )
2. Go to C:\xampp\htdocs\magento22\setup, then right-click and choose "Use Composer here"
   + A pop-up will appear
   + Type "php index.php update", then use "Enter" key and wait for the update within 30 sec - 1 minute.
3. Put a banner slider on a cms page  (Go to Backend > Content > Pages > Home Page > then insert code )

{{block class="Magento\Bannerslider\Block\Slideshow" template="bannerslider.phtml"}}